# WEBNEX

Marketplace for websites, SaaS, apps, and digital businesses.

**Stack:** Next.js 15 · Supabase · Tailwind · Netlify

## Local development

```bash
cp .env.example .env.local
# fill NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
npm install
npm run dev
```

## Deploy (Path A)

1. Push to this private repo
2. Connect the repo to [Netlify](https://app.netlify.com) → Import from Git
3. Build command: `npm run build`
4. Publish directory: `.next` (plugin handles it) — use **@netlify/plugin-nextjs**
5. Env vars on Netlify:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_APP_URL`

GitHub Actions runs `npm ci && npm run build` on every push to `main`.

## Admin

`bibilolabakare@gmail.com` is set as admin in Supabase (`profiles.role = admin`).

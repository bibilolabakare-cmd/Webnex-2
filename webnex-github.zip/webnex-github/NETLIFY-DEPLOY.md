# Netlify deployment

Build command: `npm run build`
Publish directory: `.next`
Node: `20`

For Netlify Drop, upload this project folder while logged in.
For Git deployment, use this project folder as the repository root.

Required Supabase variables:
- NEXT_PUBLIC_SUPABASE_URL
- NEXT_PUBLIC_SUPABASE_ANON_KEY

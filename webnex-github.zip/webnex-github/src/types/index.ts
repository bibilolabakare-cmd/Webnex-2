export type UserRole = "buyer" | "seller" | "admin";

export type ListingStatus =
  | "draft"
  | "pending_review"
  | "published"
  | "paused"
  | "rejected"
  | "sold"
  | "removed";

export type VerificationLevel =
  | "email"
  | "identity"
  | "revenue"
  | "traffic"
  | "business";

export type Category =
  | "websites"
  | "saas"
  | "mobile-apps"
  | "web-apps"
  | "domains"
  | "ecommerce"
  | "chrome-extensions"
  | "apis"
  | "ai-products"
  | "online-businesses"
  | "digital-products"
  | "other";

export interface Profile {
  id: string;
  username: string | null;
  full_name: string | null;
  avatar_url: string | null;
  bio: string | null;
  country: string | null;
  role: UserRole;
  is_verified: boolean;
  seller_rating: number | null;
  seller_reviews_count: number;
  created_at: string;
  updated_at: string;
}

export interface Listing {
  id: string;
  seller_id: string;
  title: string;
  slug: string;
  description: string | null;
  short_description: string | null;
  category: Category;
  categories: Category[];
  asking_price: number;
  currency: string;
  monthly_revenue: number | null;
  monthly_profit: number | null;
  monthly_traffic: number | null;
  business_age_months: number | null;
  users_count: number | null;
  country: string | null;
  technology_stack: string[];
  monetization_model: string | null;
  reason_for_selling: string | null;
  included_assets: string[] | null;
  domain: string | null;
  demo_url: string | null;
  status: ListingStatus;
  is_featured: boolean;
  is_verified: boolean;
  verification_levels: VerificationLevel[];
  views_count: number;
  saves_count: number;
  trending_score: number;
  logo_url: string | null;
  created_at: string;
  updated_at: string;
  published_at: string | null;
  // Joined
  seller?: Profile;
  images?: ListingImage[];
}

export interface ListingImage {
  id: string;
  listing_id: string;
  url: string;
  alt_text: string | null;
  sort_order: number;
  is_primary: boolean;
}

export interface ListingMetric {
  id: string;
  listing_id: string;
  metric_type: "revenue" | "traffic" | "users" | "profit";
  period: string; // e.g. "2025-01"
  value: number;
  created_at: string;
}

export interface Offer {
  id: string;
  listing_id: string;
  buyer_id: string;
  seller_id: string;
  amount: number;
  message: string | null;
  status: "pending" | "accepted" | "rejected" | "countered" | "expired" | "withdrawn";
  expires_at: string | null;
  parent_offer_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  listing_id: string | null;
  buyer_id: string;
  seller_id: string;
  last_message_at: string | null;
  created_at: string;
}

export interface Message {
  id: string;
  conversation_id: string;
  sender_id: string;
  content: string;
  is_read: boolean;
  created_at: string;
}

export interface Transaction {
  id: string;
  listing_id: string;
  buyer_id: string;
  seller_id: string;
  offer_id: string | null;
  amount: number;
  platform_fee: number;
  status: "pending" | "completed" | "cancelled" | "refunded";
  payment_status: "pending" | "paid" | "failed" | "refunded";
  payment_provider: string | null;
  created_at: string;
  completed_at: string | null;
}

export const CATEGORIES: { value: Category; label: string; icon: string }[] = [
  { value: "websites", label: "Websites", icon: "Globe" },
  { value: "saas", label: "SaaS", icon: "Cloud" },
  { value: "mobile-apps", label: "Mobile Apps", icon: "Smartphone" },
  { value: "web-apps", label: "Web Apps", icon: "Monitor" },
  { value: "domains", label: "Domains", icon: "Link" },
  { value: "ecommerce", label: "Ecommerce Stores", icon: "ShoppingCart" },
  { value: "chrome-extensions", label: "Chrome Extensions", icon: "Puzzle" },
  { value: "apis", label: "APIs", icon: "Code" },
  { value: "ai-products", label: "AI Products", icon: "Bot" },
  { value: "online-businesses", label: "Online Businesses", icon: "Briefcase" },
  { value: "digital-products", label: "Digital Products", icon: "Package" },
  { value: "other", label: "Other", icon: "MoreHorizontal" },
];

import Link from "next/link";

const footerLinks = {
  Marketplace: [
    { href: "/marketplace", label: "Explore" },
    { href: "/marketplace?sort=trending", label: "Trending" },
    { href: "/marketplace?sort=newest", label: "Newly Listed" },
    { href: "/marketplace?featured=true", label: "Featured" },
  ],
  Sell: [
    { href: "/sell", label: "List a Project" },
    { href: "/pricing", label: "Seller Plans" },
    { href: "/how-it-works#sellers", label: "How Selling Works" },
  ],
  Company: [
    { href: "/about", label: "About" },
    { href: "/trust", label: "Trust & Safety" },
    { href: "/blog", label: "Blog" },
    { href: "/contact", label: "Contact" },
  ],
  Legal: [
    { href: "/privacy", label: "Privacy Policy" },
    { href: "/terms", label: "Terms of Service" },
  ],
};

export function Footer() {
  return (
    <footer className="border-t border-[var(--color-border)] bg-[var(--color-muted)]/30">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="font-bold text-xl tracking-tight">
              <span className="bg-gradient-to-r from-[var(--color-primary)] to-violet-500 bg-clip-text text-transparent">
                WEBNEX
              </span>
            </Link>
            <p className="mt-3 text-sm text-[var(--color-muted-foreground)] leading-relaxed">
              The marketplace for the internet&apos;s next big businesses.
            </p>
          </div>

          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h3 className="font-semibold text-sm mb-3">{title}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-[var(--color-border)] flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-[var(--color-muted-foreground)]">
            © {new Date().getFullYear()} WEBNEX. All rights reserved.
          </p>
          <p className="text-sm text-[var(--color-muted-foreground)]">
            Built for serious digital business owners.
          </p>
        </div>
      </div>
    </footer>
  );
}

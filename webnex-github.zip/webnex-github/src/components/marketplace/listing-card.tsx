"use client";

import Link from "next/link";
import {
  Heart,
  Eye,
  BadgeCheck,
  MapPin,
  TrendingUp,
  Users,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatCurrency, formatNumber, cn } from "@/lib/utils";
import type { Listing } from "@/types";

interface ListingCardProps {
  listing: Listing;
  view?: "grid" | "list";
}

export function ListingCard({ listing, view = "grid" }: ListingCardProps) {
  const primaryImage =
    listing.images?.find((img) => img.is_primary)?.url ||
    listing.images?.[0]?.url ||
    listing.logo_url;

  if (view === "list") {
    return (
      <Link
        href={`/listing/${listing.slug}`}
        className="group flex flex-col sm:flex-row gap-4 p-4 rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] hover:border-[var(--color-primary)]/40 hover:shadow-md transition-all"
      >
        <div className="relative w-full sm:w-48 h-36 shrink-0 rounded-lg overflow-hidden bg-[var(--color-muted)]">
          {primaryImage ? (
            <img
              src={primaryImage}
              alt={listing.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-[var(--color-muted-foreground)] text-sm">
              No image
            </div>
          )}
          {listing.is_featured && (
            <Badge className="absolute top-2 left-2" variant="default">
              Featured
            </Badge>
          )}
        </div>

        <div className="flex-1 min-w-0 flex flex-col">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-semibold text-lg group-hover:text-[var(--color-primary)] transition-colors line-clamp-1">
                  {listing.title}
                </h3>
                {listing.is_verified && (
                  <BadgeCheck className="h-4 w-4 text-[var(--color-primary)] shrink-0" />
                )}
              </div>
              <p className="text-sm text-[var(--color-muted-foreground)] mt-1 line-clamp-2">
                {listing.short_description || listing.description}
              </p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-bold text-lg">{formatCurrency(listing.asking_price)}</p>
              {listing.monthly_revenue != null && (
                <p className="text-xs text-[var(--color-muted-foreground)]">
                  {formatCurrency(listing.monthly_revenue)}/mo rev
                </p>
              )}
            </div>
          </div>

          <div className="mt-auto pt-3 flex flex-wrap items-center gap-3 text-xs text-[var(--color-muted-foreground)]">
            <Badge variant="secondary" className="capitalize">
              {listing.category.replace("-", " ")}
            </Badge>
            {listing.monthly_traffic != null && (
              <span className="flex items-center gap-1">
                <TrendingUp className="h-3.5 w-3.5" />
                {formatNumber(listing.monthly_traffic)} visits
              </span>
            )}
            {listing.users_count != null && (
              <span className="flex items-center gap-1">
                <Users className="h-3.5 w-3.5" />
                {formatNumber(listing.users_count)} users
              </span>
            )}
            {listing.country && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5" />
                {listing.country}
              </span>
            )}
            <span className="flex items-center gap-1 ml-auto">
              <Eye className="h-3.5 w-3.5" />
              {formatNumber(listing.views_count)}
            </span>
            <span className="flex items-center gap-1">
              <Heart className="h-3.5 w-3.5" />
              {formatNumber(listing.saves_count)}
            </span>
          </div>
        </div>
      </Link>
    );
  }

  // Grid view
  return (
    <Link
      href={`/listing/${listing.slug}`}
      className="group flex flex-col rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] overflow-hidden hover:border-[var(--color-primary)]/40 hover:shadow-lg transition-all"
    >
      <div className="relative aspect-[16/10] bg-[var(--color-muted)] overflow-hidden">
        {primaryImage ? (
          <img
            src={primaryImage}
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-[var(--color-muted-foreground)] text-sm">
            No image
          </div>
        )}
        <div className="absolute top-3 left-3 flex gap-2">
          {listing.is_featured && <Badge variant="default">Featured</Badge>}
          {listing.is_verified && (
            <Badge variant="success" className="gap-1">
              <BadgeCheck className="h-3 w-3" />
              Verified
            </Badge>
          )}
        </div>
        <Button
          variant="secondary"
          size="icon"
          className="absolute top-3 right-3 h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
          onClick={(e) => {
            e.preventDefault();
            // Favorites will be wired in Phase 3
          }}
        >
          <Heart className="h-4 w-4" />
        </Button>
      </div>

      <div className="p-4 flex flex-col flex-1">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold line-clamp-1 group-hover:text-[var(--color-primary)] transition-colors">
            {listing.title}
          </h3>
        </div>

        <p className="text-sm text-[var(--color-muted-foreground)] mt-1 line-clamp-2">
          {listing.short_description}
        </p>

        <div className="mt-3 flex flex-wrap gap-1.5">
          <Badge variant="secondary" className="capitalize text-[10px]">
            {listing.category.replace("-", " ")}
          </Badge>
          {listing.technology_stack?.slice(0, 2).map((tech) => (
            <Badge key={tech} variant="outline" className="text-[10px]">
              {tech}
            </Badge>
          ))}
        </div>

        <div className="mt-auto pt-4 space-y-2">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-xs text-[var(--color-muted-foreground)]">Asking price</p>
              <p className="font-bold text-lg">{formatCurrency(listing.asking_price)}</p>
            </div>
            {listing.monthly_revenue != null && (
              <div className="text-right">
                <p className="text-xs text-[var(--color-muted-foreground)]">Revenue</p>
                <p className="font-semibold text-sm text-[var(--color-success)]">
                  {formatCurrency(listing.monthly_revenue)}/mo
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between text-xs text-[var(--color-muted-foreground)] pt-2 border-t border-[var(--color-border)]">
            <div className="flex items-center gap-3">
              {listing.monthly_traffic != null && (
                <span className="flex items-center gap-1">
                  <TrendingUp className="h-3.5 w-3.5" />
                  {formatNumber(listing.monthly_traffic)}
                </span>
              )}
              {listing.country && (
                <span className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />
                  {listing.country}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1">
                <Eye className="h-3.5 w-3.5" />
                {formatNumber(listing.views_count)}
              </span>
              <span className="flex items-center gap-1">
                <Heart className="h-3.5 w-3.5" />
                {formatNumber(listing.saves_count)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

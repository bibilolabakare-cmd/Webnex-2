"use client";

import { use, useMemo, useState } from "react";
import Link from "next/link";
import {
  Search,
  LayoutGrid,
  List,
  SlidersHorizontal,
  X,
  Plus,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { ListingCard } from "./listing-card";
import { CATEGORIES } from "@/types";
import { SAMPLE_LISTINGS } from "@/lib/sample-data";
import { cn } from "@/lib/utils";

export function MarketplaceClient({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  const params = use(searchParams);
  const [view, setView] = useState<"grid" | "list">("grid");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const query = typeof params.q === "string" ? params.q : "";
  const category = typeof params.category === "string" ? params.category : "";
  const sort = typeof params.sort === "string" ? params.sort : "newest";
  const minPrice = typeof params.min_price === "string" ? Number(params.min_price) : undefined;
  const maxPrice = typeof params.max_price === "string" ? Number(params.max_price) : undefined;
  const verified = params.verified === "true";
  const featured = params.featured === "true";

  const filteredListings = useMemo(() => {
    let results = [...SAMPLE_LISTINGS];

    if (query) {
      const q = query.toLowerCase();
      results = results.filter(
        (l) =>
          l.title.toLowerCase().includes(q) ||
          l.description?.toLowerCase().includes(q) ||
          l.short_description?.toLowerCase().includes(q) ||
          l.technology_stack.some((t) => t.toLowerCase().includes(q)) ||
          l.category.includes(q)
      );
    }

    if (category) {
      results = results.filter(
        (l) => l.category === category || l.categories.includes(category as any)
      );
    }

    if (minPrice != null && !isNaN(minPrice)) {
      results = results.filter((l) => l.asking_price >= minPrice);
    }
    if (maxPrice != null && !isNaN(maxPrice)) {
      results = results.filter((l) => l.asking_price <= maxPrice);
    }

    if (verified) {
      results = results.filter((l) => l.is_verified);
    }
    if (featured) {
      results = results.filter((l) => l.is_featured);
    }

    switch (sort) {
      case "price_asc":
        results.sort((a, b) => a.asking_price - b.asking_price);
        break;
      case "price_desc":
        results.sort((a, b) => b.asking_price - a.asking_price);
        break;
      case "revenue":
        results.sort((a, b) => (b.monthly_revenue || 0) - (a.monthly_revenue || 0));
        break;
      case "traffic":
        results.sort((a, b) => (b.monthly_traffic || 0) - (a.monthly_traffic || 0));
        break;
      case "popular":
        results.sort((a, b) => b.views_count - a.views_count);
        break;
      case "trending":
        results.sort((a, b) => b.trending_score - a.trending_score);
        break;
      case "newest":
      default:
        results.sort(
          (a, b) =>
            new Date(b.published_at || b.created_at).getTime() -
            new Date(a.published_at || a.created_at).getTime()
        );
    }

    return results;
  }, [query, category, sort, minPrice, maxPrice, verified, featured]);

  const activeFiltersCount = [category, minPrice, maxPrice, verified, featured].filter(
    Boolean
  ).length;

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Filters sidebar */}
      <aside
        className={cn(
          "lg:w-64 shrink-0 space-y-6",
          filtersOpen ? "block" : "hidden lg:block"
        )}
      >
        <div className="flex items-center justify-between lg:hidden">
          <h2 className="font-semibold">Filters</h2>
          <Button variant="ghost" size="icon" onClick={() => setFiltersOpen(false)}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <form method="get" className="space-y-6">
          {query && <input type="hidden" name="q" value={query} />}

          <div>
            <h3 className="font-semibold text-sm mb-3">Category</h3>
            <div className="space-y-1.5">
              <Link
                href={`/marketplace${query ? `?q=${query}` : ""}`}
                className={cn(
                  "block text-sm py-1.5 px-2 rounded-md transition-colors",
                  !category
                    ? "bg-[var(--color-primary)]/10 text-[var(--color-primary)] font-medium"
                    : "text-[var(--color-muted-foreground)] hover:bg-[var(--color-muted)]"
                )}
              >
                All categories
              </Link>
              {CATEGORIES.map((cat) => (
                <Link
                  key={cat.value}
                  href={`/marketplace?category=${cat.value}${query ? `&q=${query}` : ""}`}
                  className={cn(
                    "block text-sm py-1.5 px-2 rounded-md transition-colors capitalize",
                    category === cat.value
                      ? "bg-[var(--color-primary)]/10 text-[var(--color-primary)] font-medium"
                      : "text-[var(--color-muted-foreground)] hover:bg-[var(--color-muted)]"
                  )}
                >
                  {cat.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-sm mb-3">Price range</h3>
            <div className="flex gap-2">
              <Input
                name="min_price"
                type="number"
                placeholder="Min"
                defaultValue={minPrice || ""}
                className="h-9"
              />
              <Input
                name="max_price"
                type="number"
                placeholder="Max"
                defaultValue={maxPrice || ""}
                className="h-9"
              />
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-sm mb-3">Sort by</h3>
            <Select name="sort" defaultValue={sort} className="h-9">
              <option value="newest">Newest</option>
              <option value="trending">Trending</option>
              <option value="popular">Most popular</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="revenue">Highest Revenue</option>
              <option value="traffic">Highest Traffic</option>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                name="verified"
                value="true"
                defaultChecked={verified}
                className="rounded border-[var(--color-input)]"
              />
              Verified only
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                name="featured"
                value="true"
                defaultChecked={featured}
                className="rounded border-[var(--color-input)]"
              />
              Featured only
            </label>
          </div>

          <Button type="submit" className="w-full">
            Apply filters
          </Button>
          {activeFiltersCount > 0 && (
            <Link href="/marketplace">
              <Button variant="ghost" className="w-full text-sm">
                Clear all filters
              </Button>
            </Link>
          )}
        </form>
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Marketplace</h1>
            <p className="text-sm text-[var(--color-muted-foreground)] mt-1">
              {filteredListings.length} project{filteredListings.length !== 1 ? "s" : ""} found
              {query && ` for “${query}”`}
              {category && ` in ${category.replace("-", " ")}`}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="lg:hidden gap-1.5"
              onClick={() => setFiltersOpen(true)}
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge variant="default" className="ml-1 h-5 w-5 p-0 justify-center">
                  {activeFiltersCount}
                </Badge>
              )}
            </Button>

            <div className="flex border border-[var(--color-border)] rounded-md overflow-hidden">
              <button
                onClick={() => setView("grid")}
                className={cn(
                  "p-2 transition-colors",
                  view === "grid"
                    ? "bg-[var(--color-primary)] text-[var(--color-primary-foreground)]"
                    : "hover:bg-[var(--color-muted)]"
                )}
                aria-label="Grid view"
              >
                <LayoutGrid className="h-4 w-4" />
              </button>
              <button
                onClick={() => setView("list")}
                className={cn(
                  "p-2 transition-colors",
                  view === "list"
                    ? "bg-[var(--color-primary)] text-[var(--color-primary-foreground)]"
                    : "hover:bg-[var(--color-muted)]"
                )}
                aria-label="List view"
              >
                <List className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {activeFiltersCount > 0 && (
          <div className="flex flex-wrap gap-2 mb-6">
            {category && (
              <Badge variant="secondary" className="gap-1 capitalize">
                {category.replace("-", " ")}
              </Badge>
            )}
            {verified && <Badge variant="secondary">Verified</Badge>}
            {featured && <Badge variant="secondary">Featured</Badge>}
          </div>
        )}

        {filteredListings.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center border border-dashed border-[var(--color-border)] rounded-xl">
            <Search className="h-12 w-12 text-[var(--color-muted-foreground)] mb-4" />
            <h3 className="text-lg font-semibold">No projects found</h3>
            <p className="text-[var(--color-muted-foreground)] mt-2 max-w-sm">
              {category
                ? "No projects have been listed in this category yet."
                : "Try adjusting your filters or search terms."}
            </p>
            <div className="flex gap-3 mt-6">
              <Link href="/marketplace">
                <Button variant="outline">Clear filters</Button>
              </Link>
              <Link href="/sell">
                <Button className="gap-1.5">
                  <Plus className="h-4 w-4" />
                  Be the first seller
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div
            className={cn(
              view === "grid"
                ? "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5"
                : "flex flex-col gap-4"
            )}
          >
            {filteredListings.map((listing) => (
              <ListingCard key={listing.id} listing={listing} view={view} />
            ))}
          </div>
        )}

        <p className="mt-10 text-center text-xs text-[var(--color-muted-foreground)]">
          Showing development sample listings. Real data will load from the database once connected.
        </p>
      </div>
    </div>
  );
}

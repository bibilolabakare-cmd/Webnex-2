import type { ReactNode } from "react";
import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";


export const metadata: Metadata = {
  title: {
    default: "WEBNEX — Buy, Sell & Grow Digital Businesses",
    template: "%s | WEBNEX",
  },
  description:
    "Discover websites, apps, SaaS products and online businesses ready for their next owner. The marketplace for the internet's next big businesses.",
  keywords: [
    "buy website",
    "sell SaaS",
    "online business marketplace",
    "acquire digital business",
    "website marketplace",
  ],
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "WEBNEX",
    title: "WEBNEX — Buy, Sell & Grow Digital Businesses",
    description:
      "Discover websites, apps, SaaS products and online businesses ready for their next owner.",
  },
  twitter: {
    card: "summary_large_image",
    title: "WEBNEX — Buy, Sell & Grow Digital Businesses",
    description:
      "Discover websites, apps, SaaS products and online businesses ready for their next owner.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="font-sans antialiased min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}

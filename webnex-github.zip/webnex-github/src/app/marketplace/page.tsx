import { Suspense } from "react";
import { MarketplaceClient } from "@/components/marketplace/marketplace-client";

export const metadata = {
  title: "Marketplace",
  description:
    "Browse websites, SaaS products, apps, domains and online businesses for sale on WEBNEX.",
};

export default function MarketplacePage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Marketplace</h1>
        <p className="mt-2 text-[var(--color-muted-foreground)]">
          Discover digital businesses and products ready for their next owner.
        </p>
      </div>

      <Suspense
        fallback={
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="h-72 rounded-xl border border-[var(--color-border)] bg-[var(--color-muted)]/30 animate-pulse"
              />
            ))}
          </div>
        }
      >
        <MarketplaceClient searchParams={searchParams} />
      </Suspense>
    </div>
  );
}

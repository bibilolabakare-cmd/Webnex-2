import type { ReactNode } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Search,
  ArrowRight,
  Shield,
  TrendingUp,
  MessageSquare,
  CheckCircle2,
  Globe,
  Cloud,
  Smartphone,
  ShoppingCart,
  Bot,
  Briefcase,
} from "lucide-react";
import { CATEGORIES } from "@/types";

const categoryIcons: Record<string, ReactNode> = {
  websites: <Globe className="h-5 w-5" />,
  saas: <Cloud className="h-5 w-5" />,
  "mobile-apps": <Smartphone className="h-5 w-5" />,
  ecommerce: <ShoppingCart className="h-5 w-5" />,
  "ai-products": <Bot className="h-5 w-5" />,
  "online-businesses": <Briefcase className="h-5 w-5" />,
};

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-[var(--color-border)]">
        <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-primary)]/5 via-transparent to-violet-500/5" />
        <div className="container mx-auto px-4 py-20 md:py-28 relative">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold tracking-tight leading-[1.1]">
              Buy. Sell. Build.{" "}
              <span className="bg-gradient-to-r from-[var(--color-primary)] to-violet-500 bg-clip-text text-transparent">
                Grow.
              </span>
            </h1>
            <p className="mt-6 text-lg md:text-xl text-[var(--color-muted-foreground)] leading-relaxed max-w-2xl mx-auto">
              Discover websites, apps, SaaS products and online businesses ready for their next
              owner.
            </p>

            {/* Hero Search */}
            <form
              action="/marketplace"
              className="mt-10 flex flex-col sm:flex-row gap-3 max-w-xl mx-auto"
            >
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[var(--color-muted-foreground)]" />
                <Input
                  name="q"
                  type="search"
                  placeholder="Search websites, SaaS, apps, domains..."
                  className="h-12 pl-12 text-base"
                />
              </div>
              <Button type="submit" size="lg" className="h-12 px-8">
                Search
              </Button>
            </form>

            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link href="/marketplace">
                <Button size="lg" className="gap-2">
                  Explore Marketplace
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <Link href="/sell">
                <Button size="lg" variant="outline">
                  Sell Your Project
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Category Shortcuts */}
      <section className="border-b border-[var(--color-border)]">
        <div className="container mx-auto px-4 py-10">
          <div className="flex flex-wrap justify-center gap-3">
            {CATEGORIES.slice(0, 8).map((cat) => (
              <Link
                key={cat.value}
                href={`/marketplace?category=${cat.value}`}
                className="flex items-center gap-2 rounded-full border border-[var(--color-border)] bg-[var(--color-card)] px-4 py-2 text-sm font-medium hover:border-[var(--color-primary)] hover:text-[var(--color-primary)] transition-colors"
              >
                {categoryIcons[cat.value] || null}
                {cat.label}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="border-b border-[var(--color-border)]">
        <div className="container mx-auto px-4 py-16 md:py-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight">How WEBNEX works</h2>
            <p className="mt-3 text-[var(--color-muted-foreground)] max-w-xl mx-auto">
              A transparent, secure process designed for serious buyers and sellers.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                step: "01",
                title: "Discover",
                description:
                  "Browse verified listings with real metrics — revenue, traffic, tech stack and growth history.",
                icon: <Search className="h-6 w-6" />,
              },
              {
                step: "02",
                title: "Negotiate",
                description:
                  "Make offers, counter, and message sellers directly. Full offer history is tracked.",
                icon: <MessageSquare className="h-6 w-6" />,
              },
              {
                step: "03",
                title: "Transfer",
                description:
                  "Complete the transaction securely. Platform fee only on successful deals.",
                icon: <CheckCircle2 className="h-6 w-6" />,
              },
            ].map((item) => (
              <div
                key={item.step}
                className="relative rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] p-6"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[var(--color-primary)]/10 text-[var(--color-primary)]">
                    {item.icon}
                  </div>
                  <span className="text-sm font-mono text-[var(--color-muted-foreground)]">
                    {item.step}
                  </span>
                </div>
                <h3 className="font-semibold text-lg">{item.title}</h3>
                <p className="mt-2 text-sm text-[var(--color-muted-foreground)] leading-relaxed">
                  {item.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust section */}
      <section className="border-b border-[var(--color-border)] bg-[var(--color-muted)]/20">
        <div className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight">
                Built on trust & verification
              </h2>
              <p className="mt-4 text-[var(--color-muted-foreground)] leading-relaxed">
                Every listing can go through verification layers. We never auto-claim financial or
                identity data is verified — only real admin-approved status is shown.
              </p>
              <ul className="mt-6 space-y-3">
                {[
                  "Email & Identity verification",
                  "Revenue & Traffic verification",
                  "Business ownership checks",
                  "Transparent reporting system",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm">
                    <Shield className="h-4 w-4 text-[var(--color-success)]" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "Verification Levels", value: "5" },
                { label: "Secure Messaging", value: "✓" },
                { label: "Offer History", value: "Full" },
                { label: "Admin Moderation", value: "24/7" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] p-5 text-center"
                >
                  <div className="text-2xl font-bold text-[var(--color-primary)]">{stat.value}</div>
                  <div className="mt-1 text-xs text-[var(--color-muted-foreground)]">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Buyer & Seller benefits */}
      <section className="border-b border-[var(--color-border)]">
        <div className="container mx-auto px-4 py-16 md:py-20">
          <div className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto">
            <div className="rounded-xl border border-[var(--color-border)] p-8">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[var(--color-primary)]" />
                For Buyers
              </h3>
              <ul className="mt-6 space-y-3 text-sm text-[var(--color-muted-foreground)]">
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Real metrics only — no fake revenue or traffic
                </li>
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Make offers, counter, and negotiate safely
                </li>
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Save searches, watchlists & recently viewed
                </li>
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Post buyer requests so sellers find you
                </li>
              </ul>
              <Link href="/marketplace" className="mt-6 inline-block">
                <Button variant="outline">Browse Listings</Button>
              </Link>
            </div>

            <div className="rounded-xl border border-[var(--color-border)] p-8">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-[var(--color-primary)]" />
                For Sellers
              </h3>
              <ul className="mt-6 space-y-3 text-sm text-[var(--color-muted-foreground)]">
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Multi-step listing with drafts & analytics
                </li>
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Featured & promoted placement options
                </li>
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Full offer management & messaging
                </li>
                <li className="flex gap-2">
                  <CheckCircle2 className="h-4 w-4 text-[var(--color-success)] shrink-0 mt-0.5" />
                  Verification badges that actually mean something
                </li>
              </ul>
              <Link href="/sell" className="mt-6 inline-block">
                <Button>List Your Project</Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-[var(--color-primary)] to-violet-600 text-white">
        <div className="container mx-auto px-4 py-16 text-center">
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight">
            Ready to find your next digital asset?
          </h2>
          <p className="mt-3 text-white/80 max-w-lg mx-auto">
            Join buyers and sellers building the future of the internet — one acquisition at a time.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/marketplace">
              <Button size="lg" variant="secondary" className="bg-white text-[var(--color-primary)] hover:bg-white/90">
                Explore Marketplace
              </Button>
            </Link>
            <Link href="/register">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                Create Free Account
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

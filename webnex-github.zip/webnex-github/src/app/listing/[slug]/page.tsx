import { notFound } from "next/navigation";
import Link from "next/link";
import {
  BadgeCheck,
  MapPin,
  Eye,
  Heart,
  Share2,
  Flag,
  MessageSquare,
  ExternalLink,
  TrendingUp,
  Users,
  Calendar,
  DollarSign,
  Globe,
  Code,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { SAMPLE_LISTINGS } from "@/lib/sample-data";
import { formatCurrency, formatNumber } from "@/lib/utils";
import type { Metadata } from "next";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const listing = SAMPLE_LISTINGS.find((l) => l.slug === slug);

  if (!listing) {
    return { title: "Listing not found" };
  }

  return {
    title: listing.title,
    description: listing.short_description || listing.description?.slice(0, 160),
    openGraph: {
      title: listing.title,
      description: listing.short_description || undefined,
      type: "website",
    },
  };
}

export default async function ListingDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const listing = SAMPLE_LISTINGS.find((l) => l.slug === slug);

  if (!listing) {
    notFound();
  }

  const seller = listing.seller;

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="text-sm text-[var(--color-muted-foreground)] mb-6">
        <Link href="/marketplace" className="hover:text-[var(--color-foreground)]">
          Marketplace
        </Link>
        <span className="mx-2">/</span>
        <Link
          href={`/marketplace?category=${listing.category}`}
          className="hover:text-[var(--color-foreground)] capitalize"
        >
          {listing.category.replace("-", " ")}
        </Link>
        <span className="mx-2">/</span>
        <span className="text-[var(--color-foreground)]">{listing.title}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Image / Logo area */}
          <div className="relative aspect-[16/9] rounded-xl overflow-hidden bg-[var(--color-muted)] border border-[var(--color-border)]">
            {listing.logo_url || listing.images?.[0]?.url ? (
              <img
                src={listing.logo_url || listing.images?.[0]?.url}
                alt={listing.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <div className="text-center">
                  <Globe className="h-16 w-16 mx-auto text-[var(--color-muted-foreground)] mb-3" />
                  <p className="text-[var(--color-muted-foreground)]">No screenshots yet</p>
                </div>
              </div>
            )}
            <div className="absolute top-4 left-4 flex gap-2">
              {listing.is_featured && <Badge>Featured</Badge>}
              {listing.is_verified && (
                <Badge variant="success" className="gap-1">
                  <BadgeCheck className="h-3.5 w-3.5" />
                  Verified
                </Badge>
              )}
            </div>
          </div>

          {/* Title & meta */}
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <Badge variant="secondary" className="capitalize">
                {listing.category.replace("-", " ")}
              </Badge>
              {listing.verification_levels.map((level) => (
                <Badge key={level} variant="outline" className="capitalize text-xs">
                  {level} verified
                </Badge>
              ))}
            </div>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight">{listing.title}</h1>
            {listing.short_description && (
              <p className="mt-3 text-lg text-[var(--color-muted-foreground)]">
                {listing.short_description}
              </p>
            )}
            <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-[var(--color-muted-foreground)]">
              {listing.country && (
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" />
                  {listing.country}
                </span>
              )}
              <span className="flex items-center gap-1.5">
                <Eye className="h-4 w-4" />
                {formatNumber(listing.views_count)} views
              </span>
              <span className="flex items-center gap-1.5">
                <Heart className="h-4 w-4" />
                {formatNumber(listing.saves_count)} saves
              </span>
              {listing.published_at && (
                <span className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  Listed {new Date(listing.published_at).toLocaleDateString()}
                </span>
              )}
            </div>
          </div>

          {/* Key metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {listing.monthly_revenue != null && (
              <Card>
                <CardContent className="pt-5 pb-4">
                  <p className="text-xs text-[var(--color-muted-foreground)] mb-1">Monthly Revenue</p>
                  <p className="text-xl font-bold text-[var(--color-success)]">
                    {formatCurrency(listing.monthly_revenue)}
                  </p>
                </CardContent>
              </Card>
            )}
            {listing.monthly_profit != null && (
              <Card>
                <CardContent className="pt-5 pb-4">
                  <p className="text-xs text-[var(--color-muted-foreground)] mb-1">Monthly Profit</p>
                  <p className="text-xl font-bold">{formatCurrency(listing.monthly_profit)}</p>
                </CardContent>
              </Card>
            )}
            {listing.monthly_traffic != null && (
              <Card>
                <CardContent className="pt-5 pb-4">
                  <p className="text-xs text-[var(--color-muted-foreground)] mb-1">Monthly Traffic</p>
                  <p className="text-xl font-bold flex items-center gap-1">
                    <TrendingUp className="h-4 w-4 text-[var(--color-primary)]" />
                    {formatNumber(listing.monthly_traffic)}
                  </p>
                </CardContent>
              </Card>
            )}
            {listing.users_count != null && (
              <Card>
                <CardContent className="pt-5 pb-4">
                  <p className="text-xs text-[var(--color-muted-foreground)] mb-1">Users</p>
                  <p className="text-xl font-bold flex items-center gap-1">
                    <Users className="h-4 w-4 text-[var(--color-primary)]" />
                    {formatNumber(listing.users_count)}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle>About this project</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-[var(--color-foreground)] leading-relaxed whitespace-pre-line">
                {listing.description}
              </p>
            </CardContent>
          </Card>

          {/* Details grid */}
          <Card>
            <CardHeader>
              <CardTitle>Details</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                {listing.business_age_months != null && (
                  <div>
                    <dt className="text-[var(--color-muted-foreground)]">Business age</dt>
                    <dd className="font-medium mt-0.5">
                      {listing.business_age_months} months
                    </dd>
                  </div>
                )}
                {listing.monetization_model && (
                  <div>
                    <dt className="text-[var(--color-muted-foreground)]">Monetization</dt>
                    <dd className="font-medium mt-0.5">{listing.monetization_model}</dd>
                  </div>
                )}
                {listing.domain && (
                  <div>
                    <dt className="text-[var(--color-muted-foreground)]">Domain</dt>
                    <dd className="font-medium mt-0.5">{listing.domain}</dd>
                  </div>
                )}
                {listing.reason_for_selling && (
                  <div className="sm:col-span-2">
                    <dt className="text-[var(--color-muted-foreground)]">Reason for selling</dt>
                    <dd className="font-medium mt-0.5">{listing.reason_for_selling}</dd>
                  </div>
                )}
                {listing.technology_stack.length > 0 && (
                  <div className="sm:col-span-2">
                    <dt className="text-[var(--color-muted-foreground)] mb-2">Technology stack</dt>
                    <dd className="flex flex-wrap gap-1.5">
                      {listing.technology_stack.map((tech) => (
                        <Badge key={tech} variant="outline" className="gap-1">
                          <Code className="h-3 w-3" />
                          {tech}
                        </Badge>
                      ))}
                    </dd>
                  </div>
                )}
                {listing.included_assets && listing.included_assets.length > 0 && (
                  <div className="sm:col-span-2">
                    <dt className="text-[var(--color-muted-foreground)] mb-2">Included assets</dt>
                    <dd className="flex flex-wrap gap-1.5">
                      {listing.included_assets.map((asset) => (
                        <Badge key={asset} variant="secondary">
                          {asset}
                        </Badge>
                      ))}
                    </dd>
                  </div>
                )}
              </dl>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Price card */}
          <Card className="sticky top-24">
            <CardContent className="pt-6 space-y-5">
              <div>
                <p className="text-sm text-[var(--color-muted-foreground)]">Asking price</p>
                <p className="text-3xl font-bold tracking-tight">
                  {formatCurrency(listing.asking_price)}
                </p>
                {listing.monthly_revenue != null && listing.monthly_revenue > 0 && (
                  <p className="text-sm text-[var(--color-muted-foreground)] mt-1">
                    ≈ {(listing.asking_price / listing.monthly_revenue).toFixed(1)}× annual revenue
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Button className="w-full gap-2" size="lg">
                  <DollarSign className="h-4 w-4" />
                  Make an Offer
                </Button>
                <Button variant="outline" className="w-full gap-2" size="lg">
                  <MessageSquare className="h-4 w-4" />
                  Contact Seller
                </Button>
              </div>

              <div className="flex gap-2">
                <Button variant="ghost" size="sm" className="flex-1 gap-1.5">
                  <Heart className="h-4 w-4" />
                  Save
                </Button>
                <Button variant="ghost" size="sm" className="flex-1 gap-1.5">
                  <Share2 className="h-4 w-4" />
                  Share
                </Button>
                <Button variant="ghost" size="sm" className="gap-1.5">
                  <Flag className="h-4 w-4" />
                </Button>
              </div>

              {listing.demo_url && (
                <a
                  href={listing.demo_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 text-sm text-[var(--color-primary)] hover:underline"
                >
                  View live demo
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              )}
            </CardContent>
          </Card>

          {/* Seller card */}
          {seller && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Seller</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback>
                      {(seller.full_name || seller.username || "S")
                        .slice(0, 2)
                        .toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold">{seller.full_name || seller.username}</p>
                      {seller.is_verified && (
                        <BadgeCheck className="h-4 w-4 text-[var(--color-primary)]" />
                      )}
                    </div>
                    <p className="text-sm text-[var(--color-muted-foreground)]">
                      @{seller.username}
                    </p>
                  </div>
                </div>
                {seller.bio && (
                  <p className="text-sm text-[var(--color-muted-foreground)] mt-3 line-clamp-3">
                    {seller.bio}
                  </p>
                )}
                <div className="mt-3 flex items-center gap-4 text-sm">
                  {seller.seller_rating != null && (
                    <span>
                      ★ {seller.seller_rating.toFixed(1)} ({seller.seller_reviews_count} reviews)
                    </span>
                  )}
                  {seller.country && (
                    <span className="text-[var(--color-muted-foreground)]">{seller.country}</span>
                  )}
                </div>
                <Link href={`/seller/${seller.username}`}>
                  <Button variant="outline" className="w-full mt-4" size="sm">
                    View profile
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <p className="mt-12 text-center text-xs text-[var(--color-muted-foreground)]">
        This is a development sample listing. Metrics and verification status are illustrative only.
      </p>
    </div>
  );
}

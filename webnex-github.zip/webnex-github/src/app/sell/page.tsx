import type { ReactNode } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Globe,
  Cloud,
  Smartphone,
  Monitor,
  Link as LinkIcon,
  ShoppingCart,
  Puzzle,
  Code,
  Bot,
  Briefcase,
  Package,
  MoreHorizontal,
  ArrowRight,
} from "lucide-react";
import { CATEGORIES } from "@/types";

const iconMap: Record<string, ReactNode> = {
  Globe: <Globe className="h-6 w-6" />,
  Cloud: <Cloud className="h-6 w-6" />,
  Smartphone: <Smartphone className="h-6 w-6" />,
  Monitor: <Monitor className="h-6 w-6" />,
  Link: <LinkIcon className="h-6 w-6" />,
  ShoppingCart: <ShoppingCart className="h-6 w-6" />,
  Puzzle: <Puzzle className="h-6 w-6" />,
  Code: <Code className="h-6 w-6" />,
  Bot: <Bot className="h-6 w-6" />,
  Briefcase: <Briefcase className="h-6 w-6" />,
  Package: <Package className="h-6 w-6" />,
  MoreHorizontal: <MoreHorizontal className="h-6 w-6" />,
};

export const metadata = {
  title: "Sell Your Project",
  description: "List your website, SaaS, app or digital business on WEBNEX",
};

export default function SellPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
          Sell your digital project
        </h1>
        <p className="mt-4 text-lg text-[var(--color-muted-foreground)]">
          Reach serious buyers looking for websites, SaaS products, apps and online businesses.
          Create a professional listing in minutes.
        </p>
      </div>

      <div className="max-w-4xl mx-auto">
        <h2 className="text-lg font-semibold mb-6 text-center">What are you selling?</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {CATEGORIES.map((cat) => (
            <Link key={cat.value} href={`/sell/create?category=${cat.value}`}>
              <Card className="h-full hover:border-[var(--color-primary)]/50 hover:shadow-md transition-all cursor-pointer group">
                <CardContent className="pt-6 pb-5 flex flex-col items-center text-center gap-3">
                  <div className="p-3 rounded-lg bg-[var(--color-primary)]/10 text-[var(--color-primary)] group-hover:scale-110 transition-transform">
                    {iconMap[cat.icon] || <Package className="h-6 w-6" />}
                  </div>
                  <span className="font-medium text-sm">{cat.label}</span>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/register">
            <Button size="lg" className="gap-2">
              Get started
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <p className="mt-4 text-sm text-[var(--color-muted-foreground)]">
            You&apos;ll need an account to create a listing. Free to start.
          </p>
        </div>

        {/* How it works teaser */}
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">1. Create your listing</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Multi-step form covering product details, financials, traffic, tech stack and
                screenshots. Save as draft anytime.
              </CardDescription>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">2. Attract buyers</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Get discovered through search, trending, featured placements and buyer requests.
                Track views and saves in real time.
              </CardDescription>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">3. Negotiate & close</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Receive offers, counter, message buyers and complete the transaction with platform
                support.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { NextResponse, type NextRequest } from "next/server";

export async function updateSession(request: NextRequest) {
  // Auth middleware temporarily simplified for stable deploy.
  // Full Supabase session handling will be re-enabled after site is live.
  return NextResponse.next({ request });
}
